# Cobble landing page: new design for the repo

Sid designed this on a preview page and I ported it into the real Next.js files. It is on top of commit cfb34f7 (the "Redesign hero" commit). Nothing here touches the waitlist API, Supabase, Resend or the confirmation emails.

## How to apply (use a branch, not main)

Option A, patch:
1. `git checkout -b landing-v2`
2. `git apply cobble-landing.patch`

Option B, copy files: copy everything inside `files/` over the repo, keeping the same paths.

Then open a pull request. Vercel will build a preview link. Check it before merging, because main deploys to the live site.

## What changed

- `app/page.tsx`: new headline "Edit your videos in minutes", new subline, nav is now Features / Why we're building it / About the founders, new "Why" section, features section, founders section, footer with a Privacy link to /privacy. The old "Build log" section and nav link are gone (the founders section now carries the three handles).
- `app/globals.css`: soft warm gradient behind the top of the page (`.page-glow`), progress bar animation for the phone, and the browser `scroll-behavior: smooth` is removed because it is replaced by the component below.
- `app/layout.tsx`: new title and description (also removes the em dash from the title).
- `components/SmoothAnchors.tsx` (new): slow, eased scrolling for in-page links, 1.1 to 2 seconds. It stops if the visitor scrolls and jumps if "reduce motion" is on.
- `components/Features.tsx` (new): five feature cards with small illustrations.
- `components/Founders.tsx` (new): founders text, round photos, Instagram links.
- `components/HeroVisual.tsx`: while `/hero/reel.mp4` does not exist, the phone now plays the three selected clips as stills with Reels-style progress bars, instead of showing "[FINISHED REEL]". When reel.mp4 is added, the video takes over automatically.
- `components/WaitlistForm.tsx`: only visual changes. The country select is a rounded rectangle, the "Step 1 of 3" label eases in, and the "Join the waitlist" button eases away instead of disappearing. Saving logic is untouched.
- `public/founders/founder-1.jpg`, `founder-2.jpg` (new): square crops of the two founder photos.

## Please check

1. The email templates in `app/api/waitlist/route.ts` say `@peter_ishere` (one underscore). The Instagram link Sid gave for the new page is `instagram.com/peter__ishere` (two underscores). One of them is wrong. I did not edit route.ts.
2. In the preview, tapping the clips changed the reel. That is not ported. The repo hero is the auto-playing loop.
3. The feature illustrations are made-up examples (the meters, the posting week), not real product screens. The feature descriptions were written quickly, so reword anything that overpromises, especially "Cobble Helps You Win".
4. The founders text says "two 15 year old creators". That is Sid's wording.
5. I ran TypeScript (`tsc`) and ESLint and both pass. I could not run `next build` or look at it in a browser, so check the Vercel preview on desktop and a phone, especially the form opening and the features grid.
